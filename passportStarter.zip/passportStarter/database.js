let Database = {
    cindy: {
        reminders: []
    },
    alex: {
        reminders:[]
    }
}

module.exports= Database;